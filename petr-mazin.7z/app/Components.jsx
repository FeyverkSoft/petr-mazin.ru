import React from 'react';
import { ApiInstance } from "./Api.jsx";
import { Lang } from './lang.jsx';

/// Холст 
export class Page extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            additionalIcons: this.props.AdditionalIcons || []
        }
        this.GetAdditionalIcons = this.GetAdditionalIcons.bind(this);
    }

    componentWillMount() {
        if (this.props.ShowAdditionalIcons)
            this.GetAdditionalIcons();
    }
    ///получаем значки соц сетей
    GetAdditionalIcons() {
        if (this.props.AdditionalIcons) {
            this.setState({ additionalIcons: $this.props.AdditionalIcons });
        }
        else {
            ApiInstance.MainData.GetAdditionalIcons((data) => {
                this.setState({ additionalIcons: data });
            });
        }
    }
    render() {
        let shovSt = this.props.SubTitle != undefined;
        let searchField = this.props.onSearch != undefined;
        return (
            <div className="page">
                <div className="page-title">{this.props.Title}</div>
                <div className={this.props.className ? `paper ${this.props.className}` : 'paper'}>
                    {searchField ?
                        <div className="search-field">
                            <OmniTextBox
                                icons="search"
                                placeHolder={Lang("search")}
                                onChange={this.props.onSearch}
                            />
                        </div> : ''}
                    {shovSt ?
                        <div className="sub-title">
                            {this.props.SubTitle}
                        </div>
                        : ''}
                    <div className="paper-content">
                        {this.props.children}
                    </div>
                    {
                        //<!--AdditionalIcons блок дополнительных значков -->
                        this.props.ShowAdditionalIcons && this.state.additionalIcons && this.state.additionalIcons.length > 0 ?
                            <AdditionalIcons items={this.state.additionalIcons}
                                pageTitle={(this.props.Title || '') + ' ' + (this.props.SubTitle || '')} /> :
                            ''
                    }
                </div>
            </div>
        );
    }
}

///Текстовое поле поиска в материл дезайн стиле
export class OmniTextBox extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            IsHide: this.props.isHide || true,
            value: this.props.value || '',
            typingTimeOut: 0
        };
        this.hide = this.hide.bind(this);
        this.show = this.show.bind(this);
        this.onChange = this.onChange.bind(this);
    }

    hide() {
        if (!this.state.IsHide)
            this.setState({ IsHide: true })
    }

    show() {
        if (this.state.IsHide)
            this.setState({ IsHide: false })
    }

    onChange(event) {
        let $this = this;
        if (this.props.onChange) {
            if ($this.state.typingTimeout) {
                clearTimeout($this.state.typingTimeout);
            }

            $this.setState({
                value: event.target.value,
                typingTimeout: setTimeout(function () {
                    $this.props.onChange($this.state.value);
                }, 500)
            });
        }
    }

    render() {
        let $this = this;
        return (
            <div className="omni-field">
                <span className="open-icon material-icon"
                    onClick={$this.show}>
                    {$this.props.icons}
                </span>
                <div className={`input-field-wrapper ${$this.state.IsHide ? 'hide-field' : ''}`}>
                    <input className="input-field"
                        placeholder={$this.props.placeHolder}
                        onChange={$this.onChange}
                        value={$this.state.value}
                    />
                    <span className={`close-icon material-icon ${$this.state.IsHide ? 'hide' : ''}`}
                        onClick={$this.hide}>
                        close
                    </span>
                    <span className="bar main-bar" />
                </div>
            </div>);
    }
}

// значки соц сетей и иной ериси с низу странички
export class AdditionalIcons extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            items: props.items || [],
            pageTitle: props.pageTitle || ''
        };
        this.getData = this.getData.bind(this);
        this.IconClick = this.IconClick.bind(this);
    }
    getData(name) {
        if (name)
            switch (name.toLowerCase().trim()) {
                case "_uri":
                    return window.location + '';
                case "_title":
                    return this.state.pageTitle;
            }
        return name;
    }
    IconClick(e) {
        if (e && e.target && e.target.dataset && e.target.dataset['id']) {
            let $this = this;
            let item = $this.state.items.firstOrDefault(x => (x.id || item.icon) == e.target.dataset['id']);
            if (item.uri) {
                let uri = item.uri;
                if (item.isShareLink) {
                    uri = `${uri}?`;
                    if (item.shareParams)
                        item.shareParams.forEach(element => {
                            let data = $this.getData(element.val);
                            if (data && data != '')
                                uri = `${uri}${element.name}=${data}&`
                        });
                }
                window.open(uri.trim("&"), '_blank');
            }
        }
        return;
    }
    render() {
        let $this = this;
        return (
            <div className="additional-icons-wrapper">
                {
                    $this.state.items.map(item => {
                        return (
                            <div className={`icons ${item.icon}`}
                                data-id={item.id || item.icon}
                                key={`icon${item.id || item.icon}`}
                                onClick={$this.IconClick}></div>
                        )
                    })
                }
            </div>);
    }
}

///Плашки
export class Tils extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            CurrentItems: props.Items || [],
            CurrentPage: props.CurrentPage || 0,
            TotalPages: props.TotalPages || 0
        };
    }
    render() {
        let $this = this;
        return (
            <div className="tils-wrapper">
                <Til />
                <Pagination />
            </div>);
    }
}
///Плашка
export class Til extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        let $this = this;
        return (
            <div className="til">
            </div>);
    }
}

///Пагинатор
export class Pagination extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            
        };
    }
    render() {
        let $this = this;
        return (
            <div className="pagination">
            </div>);
    }
}